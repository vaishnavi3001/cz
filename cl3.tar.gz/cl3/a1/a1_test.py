from a1 import BinarySearch
import unittest,sys

class MyTestCase(unittest.TestCase):
	def test_positive(self):
		data = [0,1,2,3,4,5]
		objt1 = BinarySearch(data)
		self.assertEqual(objt1.search(3),3)

	def test_negative(self):
		objt2 = BinarySearch([0,1,2,3,4,5])
		self.assertEqual(objt2.search(2000),-1)
unittest.main()