from flask import Flask, request,render_template
import pymongo
app = Flask(__name__)

conn = pymongo.MongoClient('localhost',27017)
db = conn.plagPrac1
colN = db.plagPrac1

@app.route('/')
def home():
	return render_template('homep.html')

@app.route('/',methods=['POST'])
def checkPlag():
	text = request.form['text1']

	file = open("data.txt", "w")
	coll = colN.find()
	for doc in coll:
		file.write(doc['text'])
	file.close()

	file2 = open("data.txt","r").read()

	text = text.split(".")
	source = file2.split(".")

	ip_lines=[]
	src_lines=[]
	plagtxt=[]

	for line in text:
		if line[:1] == ' ':
			line = line[1:]
		line= line.replace("\n",'')
		if line == '':
			pass
		else:
			ip_lines.append(line)

	for line in source:
		if line[:1] == ' ':
			line = line[1:]
		line= line.replace("\n",'')
		if line == '':
			pass
		else:
			src_lines.append(line)


	c=0
	for line1 in ip_lines:
		for line2 in src_lines:
			if line1 == line2:
				c+=1
				plagtxt.append(line2)

	a=int( (c*100)/(len(ip_lines)))

	return "<h1>plagarization:"+str(a)+"</h1>"

if __name__ == '__main__':
	app.run(host='0.0.0.0', port=8080, debug=True)
#mongodb commands
#use plagarize
#db.plagarize.insert({"text":"<Enter text here.this is your dataset.do this multiplte times to increase dataset>"})
#db.plagarize.find.pretty() <Do this to check is entries are made properly>
			




