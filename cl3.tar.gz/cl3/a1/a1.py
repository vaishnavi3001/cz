import sys

class BinarySearch:
	def __init__(self, data=None, pre_sorted=False):
		if data != None:
			self.set_data(data)

	def set_data(self, data, pre_sorted=False):
		if pre_sorted: self.data = data
		else: 
			lend = len(data)-1
			for i in range(lend):
				for j in range(lend - 1 - i):
					if(data[j]>data[j+1]):
						data[j+1],data[j]=data[j],data[j+1]
			self.data = data
			print 'sorted array: ', self.data

	def search(self, key):
		def binsearch(base, a, key):
			if len(a) == 1:        return ( base if a[0] == key else -1 )
			if a[len(a)/2] == key: return base+len(a)/2
			if a[len(a)/2] < key:  return binsearch(base+len(a)/2, a[len(a)/2:], key)
			if a[len(a)/2] > key:  return binsearch(base, a[:len(a)/2], key)
		return binsearch(0, self.data, key)

if __name__ == '__main__':
	fname = raw_input('Enter file name: ')
	data = [ int(number) for number in open(fname).read().split() ]
	print 'unsorted array: ', data
	binsearch = BinarySearch(data)
	print(binsearch.search(input('Enter key:')))